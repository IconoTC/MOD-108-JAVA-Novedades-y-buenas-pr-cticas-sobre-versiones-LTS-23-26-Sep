package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class AppMain {
	
	// No funciona con variables globales o propiedades
	// Solo funciona con variables locales
	//var a = 89;
	

	public static void main(String[] args) {
		
		// Una vez que ha inferido el tipo de dato no lo puedo cambiar
		var dato = 64;  // dato es de tipo int
		//dato = "hola";  // Error porque es numerica
		dato = 100;
		
		// Es obligatorio pasar un valor para que pueda inferir el tipo
		// var otra;
		// var otra = null;
		
		// Tampoco funciona en declaraciones multiples
		//var a, b = 7;
		//var a=2, b = 7;
		
		// En arrays funciona dependiendo de como se declaren
		//var letras[] = {'a','e','i','o','u'};
		var letras = new char[] {'a','e','i','o','u'};
		var letras2 = new char[10];
		
		// En las colecciones tambien funciona
		var lista = new ArrayList<>(); // lista de objetos
		var lista2 = new ArrayList<String>();  // lista de cadenas de texto
		var lista3 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5));  // Lista de numeros
		var lista4 = new ArrayList<>(Arrays.asList(1,2,3,4,5));  // Lista de numeros
		
		var set = new HashSet<>();		// Conjunto de objetos
		var set2 = new HashSet<String>();	// Conjunto de cadenas de texto
		var set3 = new HashSet<String>(Arrays.asList("Juan", "Maria", "Pedro")); // Conjunto de cadenas de texto
		var set4 = new HashSet<>(Arrays.asList("Juan", "Maria", "Pedro")); // Conjunto de cadenas de texto
		
		var mapa = new HashMap<>();   // Map<Object,Object>
		var mapa2 = new HashMap<String, Double>();
		
		// Tambien funciona con bucles
		for(var num=1; num <= 10; num++) {
			System.out.println(num);
		}
		
		for(var letra : letras) {
			System.out.println(letra);
		}

	}

}




