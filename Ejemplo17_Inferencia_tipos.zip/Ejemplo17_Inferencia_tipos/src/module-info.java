/**
 * 
 */
/**
 * 
 */
module Ejemplo17_Inferencia_tipos {
}