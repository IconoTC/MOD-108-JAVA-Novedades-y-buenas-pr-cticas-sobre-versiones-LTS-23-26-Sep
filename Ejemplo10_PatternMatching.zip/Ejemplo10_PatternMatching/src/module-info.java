/**
 * 
 */
/**
 * 
 */
module Ejemplo10_PatternMatching {
}