package com.viewnext;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.viewnext.models.Producto;

public class DeserializarObjetos {

	public static void main(String[] args) {
		
		try (FileInputStream fis = new FileInputStream("producto.ser");
			 ObjectInputStream inputStream = new ObjectInputStream(fis);){
			
			// Deserializacion
			Producto recuperado = (Producto) inputStream.readObject();
			
			System.out.println(recuperado);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
