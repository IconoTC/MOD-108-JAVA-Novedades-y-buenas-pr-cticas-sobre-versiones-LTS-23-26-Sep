package com.viewnext;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.viewnext.models.Producto;

public class SerializarObjetos {

	public static void main(String[] args) {
		
		Producto producto = new Producto(1, "Pantalla", 129.95);
		
		try (FileOutputStream fichero = new FileOutputStream("producto.ser");
			 ObjectOutputStream outputStream = new ObjectOutputStream(fichero);	) {
			
			// Serializacion
			outputStream.writeObject(producto);
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
