package com.viewnext;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LeerFichero {

	public static void main(String[] args) {
		
		try(FileReader fichero = new FileReader("datos.txt");
			BufferedReader buffer = new BufferedReader(fichero);	){
			
			// Leer el contenido del fichero
			String linea;
			while ( (linea = buffer.readLine()) != null ){
				System.out.println(linea);
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
