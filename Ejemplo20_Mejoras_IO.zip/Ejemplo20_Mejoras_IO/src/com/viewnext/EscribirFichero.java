package com.viewnext;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class EscribirFichero {

	public static void main(String[] args) {
		
		try (FileWriter fichero = new FileWriter("datos.txt");
			 BufferedWriter bufferedWriter = new BufferedWriter(fichero);	) {
			
			// Escribir contenido en el fichero
			bufferedWriter.write("Hola, que tal?");
			bufferedWriter.write("\n");
			bufferedWriter.write("Por fin es jueves");
			
		} catch(IOException e) {
			e.printStackTrace();
		}

	}

}
