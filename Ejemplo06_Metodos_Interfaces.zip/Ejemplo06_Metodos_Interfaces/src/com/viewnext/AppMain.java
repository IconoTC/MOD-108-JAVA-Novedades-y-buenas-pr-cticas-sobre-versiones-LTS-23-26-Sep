package com.viewnext;

import com.viewnext.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Invocar el metodo estatico
		ItfzMetodos.estatico();
		
		// Invocar al metodo default
		ItfzMetodos impl = new ItfzMetodos() {
		};
		impl.defecto();
		
		// Invocar a los metodos privados
		// impl.mayusculas();   ERROR de acceso
		
		System.out.println(impl.procesarTexto("Hola, que tal?"));

	}

}
