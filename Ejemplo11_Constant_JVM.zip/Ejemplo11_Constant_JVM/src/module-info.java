/**
 * 
 */
/**
 * 
 */
module Ejemplo11_Constant_JVM {
}