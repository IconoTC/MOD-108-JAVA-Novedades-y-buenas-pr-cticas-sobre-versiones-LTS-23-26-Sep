package com.viewnext;

public class PatronParenthesized {

	public static void main(String[] args) {
		
		Object email = "pepito@gmail.com";
		
//		switch (email) {
//			case String s && (s.length() > 3) -> System.out.println("El email es correcto");
//			
//			default -> System.out.println("Email incorrecto");
//		}
		
		switch (email) { 
			case String s -> { 
				if (s.length() > 3 && s.contains("@") && s.contains(".")) { 
					System.out.println("El email es correcto"); 
				} else {
					System.out.println("Formato incorrecto");
				}
			} 

			default -> System.out.println("Email es incorrecto"); 
		}

	}

}
