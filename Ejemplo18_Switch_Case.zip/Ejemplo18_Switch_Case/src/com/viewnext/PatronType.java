package com.viewnext;

public class PatronType {
	
	public static void main(String[] args) {
		
		// Hay que poner en jdk 21
		
		Object dato = "Pepito";
		
		// Patron Type
		String formato = switch (dato) {
			case Integer entero -> String.format("int %d", entero);
			case Double real -> String.format("double %.1f", real);
			case Long enteroLong -> String.format("long %d", enteroLong);
			case Float realFloat -> String.format("float %.1f", realFloat);
			case String texto -> texto.toUpperCase();
			case null -> "Valor nulo";
			default -> dato.toString();
		
		};
		
		System.out.println(formato);
	}

}
