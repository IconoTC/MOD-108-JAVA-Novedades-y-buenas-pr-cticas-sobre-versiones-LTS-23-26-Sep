package com.viewnext;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class EjemploLocalDate {

	public static void main(String[] args) {
		// Fecha de hoy
		LocalDate hoy = LocalDate.now();
		System.out.println(hoy);
		
		// Fecha de mi cumpleaños
		LocalDate miCumple = LocalDate.of(2024, Month.JULY, 1);
		System.out.println(miCumple);
		
		// Ya ha sido tu cumpleaños?
		System.out.println("Ya ha sido tu cumpleaños? " + hoy.isAfter(miCumple));
		
		// En que dia de la semana fue tu cumpleaños
		System.out.println("Dia de la semana " + miCumple.getDayOfWeek());
		
		// Es bisiesto?
		System.out.println("Es bisiesto? " + hoy.isLeapYear());
		
		// Cuando es el proximo jueves?
		System.out.println("Cuando es el proximo jueves? " + hoy.with(TemporalAdjusters.next(DayOfWeek.THURSDAY)));
		
		// Sumar un mes
		System.out.println("Dentro de un mes " + hoy.plusMonths(1));
		
		// Sumar un dia
		System.out.println("Mañana " + hoy.plusDays(1));
		
		// Restar un año
		System.out.println("Hace un año " + hoy.minusYears(1));
	}

}
