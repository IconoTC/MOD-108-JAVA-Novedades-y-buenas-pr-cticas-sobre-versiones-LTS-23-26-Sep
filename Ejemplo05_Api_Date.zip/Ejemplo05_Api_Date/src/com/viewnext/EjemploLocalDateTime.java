package com.viewnext;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class EjemploLocalDateTime {
	
	public static void main(String[] args) {
		
		// El vuelo es el 19 de Diciembre de 2024 a las 21:30
		LocalDateTime vuelo = LocalDateTime.of(2024, Month.DECEMBER, 19, 21, 30);
		System.out.println(vuelo);
		
		// Otra forma
		LocalDate fecha = LocalDate.of(2024, Month.DECEMBER, 19);
		LocalTime hora = LocalTime.of(21, 30);
		LocalDateTime vuelo2 = LocalDateTime.of(fecha, hora);
		System.out.println(vuelo2);
		
		// Aplazar el vuelo una semana
		System.out.println("Aplazar 1 semana: " + vuelo.plusWeeks(1));
		
		// Adelantar el vuelo2 una semana
		System.out.println("Adelantar 1 semana: " + vuelo2.minusWeeks(1));
	}

}
