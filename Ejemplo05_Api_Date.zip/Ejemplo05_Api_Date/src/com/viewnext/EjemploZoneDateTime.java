package com.viewnext;

import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class EjemploZoneDateTime {

	public static void main(String[] args) {
		// Mostrar las zonas horarias
		System.out.println(ZoneId.getAvailableZoneIds());
		
		// Crear la zona horaria
		ZoneId USEast = ZoneId.of("America/New_York");
		
		// Hora en Madrid
		System.out.println("Ahora en Madrid: " + LocalTime.now());
		
		// Hora en New York
		System.out.println("Ahora en New York: " + ZonedDateTime.now(USEast));

	}

}
