package com.viewnext.persistence;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.viewnext.models.Producto;

public class ProductosDAO {
	
	private List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Teclado", 37.50),
			new Producto(3, "Raton", 18.75),
			new Producto(4, "Scanner", 400),
			new Producto(5, "Impresora", 110)
	);
	
	public Optional<Producto> buscarProducto(int id){
		
		// Version 1
//		for(Producto p : lista) {
//			if (p.getId() == id) {
//				// Crear un optional del producto encontrado
//				return Optional.of(p);
//			}
//		}
		
		// Si no lo encuentro devuelvo un optional vacio
//		return Optional.empty();
		
		
		// Version 2
		return lista.stream()
				.filter(prod -> prod.getId() == id)
				.findFirst();		
		
	}

}
