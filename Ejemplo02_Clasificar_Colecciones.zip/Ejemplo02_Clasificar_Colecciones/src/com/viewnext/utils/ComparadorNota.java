package com.viewnext.utils;

import java.util.Comparator;

import com.viewnext.models.Alumno;

public class ComparadorNota implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		if (alum1.getNota() > alum2.getNota())
			return 1;
		else if (alum1.getNota() < alum2.getNota())
			return -1;
		else
			return 0;
	}

}
