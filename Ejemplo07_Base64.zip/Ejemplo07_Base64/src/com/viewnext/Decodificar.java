package com.viewnext;

import java.util.Base64;

public class Decodificar {

	public static void main(String[] args) {
		
		String cadena = "QW5hYmVsIFZlZ2Fz";
		
		// Decodificar la cadena utilizando Base64 y obtener el nombre
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] arrayBytes = decoder.decode(cadena);
		String nombre = new String(arrayBytes);
		
		// Mostrar el nombre recuperado
		System.out.println(nombre);

	}

}
