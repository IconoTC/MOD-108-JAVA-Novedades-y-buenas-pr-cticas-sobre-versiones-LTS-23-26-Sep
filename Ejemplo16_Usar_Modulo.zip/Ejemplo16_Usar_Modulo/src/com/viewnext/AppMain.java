package com.viewnext;

import com.viewnext.models.Direccion;
import com.viewnext.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Direccion dir = new Direccion("Mayor", 5, "Madrid");
		Empleado empleado = new Empleado(1, "Juan", 45000, dir);
		
		System.out.println(empleado);

	}

}


