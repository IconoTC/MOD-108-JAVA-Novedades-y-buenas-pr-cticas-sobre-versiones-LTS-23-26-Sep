/**
 * 
 */
/**
 * 
 */
module Ejemplo16_Usar_Modulo {
	
	// Para poder usar el modulo 
	// es necesario agregarlo como dependencia en el build path
	
	// requires nombre_modulo
	requires Ejemplo15_Crear_Modulo;
}