package com.viewnext;

import java.util.Optional;

public class Ejemplo_orElseThrow {

	public static void main(String[] args) {
		
		Optional<String> optionalValue = Optional.ofNullable(null);
		
		// java.util.NoSuchElementException: No value present
		//String dato = optionalValue.orElseThrow();
		
		// java.lang.RuntimeException: Valor nulo
		String dato = optionalValue.orElseThrow(() -> new RuntimeException("Valor nulo") );
		System.out.println("Valor: " + dato);

	}

}
