package com.viewnext;

import java.util.Optional;
import java.util.stream.Stream;

public class Ejemplo_stream {
	
	public static void main(String[] args) {
		
		Optional<String> optionalValue = Optional.of("dato");
		
		// Recupero el dato guardado en el optional como un stream
		Stream<String> stream = optionalValue.stream();
		
		stream
			.map(item -> item.toUpperCase())
			.forEach(System.out::println);
		
	}

}
