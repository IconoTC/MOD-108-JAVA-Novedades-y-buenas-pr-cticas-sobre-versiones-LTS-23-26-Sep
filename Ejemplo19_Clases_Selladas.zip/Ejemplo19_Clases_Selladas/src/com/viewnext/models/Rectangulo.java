package com.viewnext.models;

// Rectangulo no tiene permisos para heredar de Figura
public class Rectangulo extends Figura{
	
	@Override
	double calcularArea() {
		// TODO Auto-generated method stub
		return 0;
	}

}
