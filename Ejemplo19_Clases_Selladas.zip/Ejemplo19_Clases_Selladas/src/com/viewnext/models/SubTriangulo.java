package com.viewnext.models;

public class SubTriangulo extends Triangulo{
	
	// .......

}
