package com.viewnext;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.viewnext.models.Producto;

public class Practica {
	
	public static List<Producto> filtrarProductos(List<Producto> lista, Predicate<Producto> filtro){
		return lista.stream()
				.filter(filtro)
				.collect(Collectors.toList());
	}

	public static void main(String[] args) {
		List<Producto> lista = Arrays.asList(
				new Producto(1, "Pantalla", 129.95),
				new Producto(2, "Teclado", 37.50),
				new Producto(3, "Raton", 18.75),
				new Producto(4, "Scanner", 400),
				new Producto(5, "Impresora", 110)
		);
		
		// Filtrar por precio > 100
		filtrarProductos(lista, prod -> prod.getPrecio() > 100)
			.forEach(System.out::println);
		System.out.println("---------------");
		
		
		// Filtrar por descripcion tenga mas de 6 caracteres
		filtrarProductos(lista, prod -> prod.getDescripcion().length() > 6)
			.forEach(System.out::println);
		System.out.println("---------------");
		
		
		// Filtrar los productos que comienzan por la letra P
		filtrarProductos(lista, prod -> prod.getDescripcion().charAt(0) == 'P')
			.forEach(System.out::println);
		System.out.println("---------------");

	}

}
