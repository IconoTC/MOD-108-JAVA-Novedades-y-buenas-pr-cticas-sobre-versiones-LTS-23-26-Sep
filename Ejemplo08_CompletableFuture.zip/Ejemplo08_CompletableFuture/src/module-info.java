/**
 * 
 */
/**
 * 
 */
module Ejemplo08_CompletableFuture {
}