package com.viewnext;

import java.util.concurrent.CompletableFuture;

public class Ejemplo1_Crear_Completable {

	public static void main(String[] args) {
		
		CompletableFuture<String> cFuture = new CompletableFuture<String>();
		
		cFuture.complete("Esto es una prueba");
		
		cFuture.thenAccept(resultado -> System.out.println(resultado));

	}

}
